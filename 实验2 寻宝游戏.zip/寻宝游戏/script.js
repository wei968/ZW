document.addEventListener('DOMContentLoaded', function () {
    const startButton = document.getElementById('startButton');
    startButton.addEventListener('click', startTreasureHunt);
});


// 模拟寻宝过程的函数
async function startTreasureHunt() {
    const stage = document.querySelector('.stage');
    const items = stage.querySelectorAll('.item');
    const delayMap = {
        'clue': 1000,
        'location': 1500,
        'trap': 1200,
        'box': 2000,
        'key': 1500,
        'treasure': 1000
    };
    let index = 0;
    async function animateNextItem() {
        if (index < items.length) {
            const item = items[index];
            item.style.opacity = 1;
            await new Promise(resolve => setTimeout(resolve, delayMap[item.classList[1]]));
            item.style.opacity = 0;
            index++;
            await animateNextItem();
        }
    }
    await animateNextItem();
}


// 模拟宝藏地图API
class TreasureMap {
    static async getInitialClue() {
        await new Promise(resolve => setTimeout(resolve, 1000));
        return "在古老的图书馆里找到了第一个线索...";
    }

    static async decodeAncientScript(clue) {
        await new Promise(resolve => setTimeout(resolve, 1500));
        if (!clue) {
            throw new Error("没有线索可以解码!");
        }
        return "解码成功!宝藏在一座古老的神庙中...";
    }

    static async searchTemple(location) {
        await new Promise(resolve => setTimeout(resolve, 2000));
        const random = Math.random();
        if (random < 0.5) {
            throw new Error("糟糕!遇到了神庙守卫!");
        }
        return "找到了一个神秘的箱子...";
    }

    static async openTreasureBox() {
        await new Promise(resolve => setTimeout(resolve, 1000));
        return "恭喜!你找到了传说中的宝藏!";
    }

    // 新添加的方法：解决神庙谜题
    static async solveTemplePuzzle() {
        await new Promise(resolve => setTimeout(resolve, 1500));
        const random = Math.random();
        if (random < 0.3) {
            return "成功解开神庙谜题，获得了打开宝藏箱的特殊钥匙!";
        } else {
            return "虽然没有完全解开谜题，但也找到了打开宝藏箱的其他方法。";
        }
    }

    // 新添加的方法：避开陷阱
    static async avoidTraps() {
        await new Promise(resolve => setTimeout(resolve, 1200));
        const random = Math.random();
        if (random < 0.2) {
            throw new Error("不小心触发了陷阱，寻宝失败!");
        } else {
            return "成功避开了所有陷阱，继续前进。";
        }
    }
}


async function findTreasureWithAsyncAwait() {
    try {
        const clue = await TreasureMap.getInitialClue();
        console.log(clue);

        const location = await TreasureMap.decodeAncientScript(clue);
        console.log(location);

        const success = await TreasureMap.avoidTraps();
        console.log(success);

        const box = await TreasureMap.searchTemple(location);
        console.log(box);

        const key = await TreasureMap.solveTemplePuzzle();
        console.log(key);

        const treasure = await TreasureMap.openTreasureBox();
        console.log(treasure);
    } catch (error) {
        console.error("任务失败:", error.message);
    }
}


findTreasureWithAsyncAwait();


